package com.example.devsettingsopener

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private fun openDeveloperOptions() {
        val actions = listOf(
            Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
            "android.settings.APPLICATION_DEVELOPMENT_SETTINGS",
            Settings.ACTION_DEVICE_INFO_SETTINGS,
            Settings.ACTION_SETTINGS
        )
        var launched = false
        for (action in actions) {
            runCatching {
                val intent = Intent(action).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    launched = true
                    return@runCatching
                }
            }
        }
        if (launched) {
            finish()
        } else {
            Toast.makeText(this, "Couldn't open Developer Options.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        window.decorView.post { openDeveloperOptions() }
        findViewById<Button>(R.id.openBtn).setOnClickListener { openDeveloperOptions() }
    }
}
