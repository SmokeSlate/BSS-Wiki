plugins {
    id("com.android.application") version "8.5.2" apply false
    kotlin("android") version "2.0.0" apply false
}
