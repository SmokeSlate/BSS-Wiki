# DevSettingsOpener (Android)

A tiny Android app that opens *Developer Options* (with fallbacks).

## How it works
On launch, it tries these actions in order:
1. `Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS`
2. `"android.settings.APPLICATION_DEVELOPMENT_SETTINGS"` (legacy string)
3. `Settings.ACTION_DEVICE_INFO_SETTINGS`
4. `Settings.ACTION_SETTINGS`

If one resolves on your device, it opens that Settings screen and closes itself.

## Build (Android Studio)
1. Open Android Studio → **Open** → select this folder.
2. Let Gradle sync.
3. **Build > Build APK(s)** (or **Run** on a connected device).  
   The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build (Gradle CLI)
If you have the Gradle wrapper created by Android Studio:
```bash
./gradlew assembleDebug
```
The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Install via ADB
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Directly open Developer Options via ADB (no APK)
```bash
adb shell am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS
```

> Note: Some OEM builds restrict deep links to Developer Options. In that case a fallback Settings page will open.
